﻿//----------------------------------------------
// LitJson Ruler
// © 2015 yedo-factory
// auto-generated
//----------------------------------------------
namespace LJR
{
	public static class Setting
	{
		public static string BaseUrl = "file:///Applications/workspace/LJR/Assets/LJR/Demo/Server/";
	}
}
