﻿//----------------------------------------------
// LitJson Ruler
// © 2015 yedo-factory
//----------------------------------------------
namespace LJR
{
    /// <summary>
    /// レスポンス基底クラス
    /// </summary>
    public abstract class Responce
	{
        
	}
}
